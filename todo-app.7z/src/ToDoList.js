import React from 'react';

function ToDoList(props){
return(
<>
<li className="list-group-item"><i className="fa fa-close" onClick={() => props.customHandler(props.id)}></i><span className="li-content"> {props.text}</span></li>
</>
);
}

export default ToDoList;