import React, { useState } from 'react';
import ToDoList from './ToDoList';
import './ToDoApp.css';

const ToDoApp = () => {
    //array destructuring for input element value and onChange function
    const [inputElement, setInputElement] = useState();
    // for storing the value enter in the input field in an array after clicking on the button
    const [items, setItems] = useState([]);
    const inputHandler = (e) => {
        setInputElement(e.target.value)
    }
    const clickHandler = () => {
        setItems((oldValue) => {
            return [...oldValue, inputElement]
        })
    }
    const deleteHandler = (id) => {
      setItems((oldValue) => {
          return oldValue.filter((arrElement, index) => {
              return index !== id
          })
      })
    }
    
    return (
        <>
            <div className="container">
                <div className="row align-items-center height-100">
                    <div className="col-4">
                    </div>
                    <div className="col-4">
                        <h4>{inputElement}</h4>
                        <div className="input-wrapper">
                    <input type="text" className="form-control" value={inputElement} onChange={inputHandler} />
                    <button type="button" className="btn btn-style" onClick={clickHandler}> Add</button> 
                    </div>
                        <div className="card">
                          <ul className="list-group list-group-flush">
                          {items.map((item, index) => <ToDoList key={index} id={index} text={item} customHandler={deleteHandler} />
                          )}
                            </ul>
                        </div>
                    </div>
                    <div className="col-4">
                    </div>
                </div>
            </div>
        </>
    );
}

export default ToDoApp;